#ifndef _SHA1_H_
#define _SHA1_H_


void hash_pool (const void *pooldata, void *out);


#endif

