
#ifndef _MIX_H_
#define _MIX_H_

void mix (const void *in, size_t nbytes, void *pooldata);

#endif
